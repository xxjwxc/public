package mylog

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"time"

	"github.com/xxjwxc/public/dev"
	"github.com/xxjwxc/public/myelastic"
	"github.com/xxjwxc/public/myqueue"
)

var _eslogTuple eslogTuple

type eslogTuple struct {
	ptr_que        *myqueue.MyQueue
	elastic        myelastic.MyElastic
	isSaveFile     bool   //默认存文件
	isSaveToEs     bool   //默认不保存
	local_Log_file string //默认存放文件的目录
	exe_path       string
}

func init() {
	if dev.IsRunTesting() { //测试时候不创建
		return
	}

	_eslogTuple.ptr_que = nil
	_eslogTuple.isSaveFile = true      //默认存文件
	_eslogTuple.isSaveToEs = false     //默认不保存
	_eslogTuple.local_Log_file = "log" //默认存放文件的目录

	file, _ := exec.LookPath(os.Args[0])
	path, _ := filepath.Abs(file)
	_eslogTuple.exe_path = filepath.Dir(path)

	BuildDir(_eslogTuple.local_Log_file)
	_eslogTuple.ptr_que = myqueue.NewSyncQueue()
	es_path := ""
	if len(es_path) > 0 {
		_eslogTuple.elastic = myelastic.OnInitES(es_path)
		_eslogTuple.elastic.CreateIndex(Http_log_index, mapping)
	}
	go onConsumerLog()
}

/*
	发送日志请求
*/
func OnLog(es_index, es_type, es_id string, data LogInfo) {
	//	local, _ := time.LoadLocation("Local")
	//	data.Creat_time = time.Now().In(local)
	b, err := json.Marshal(data.Data)
	if err != nil {
		log.Println("OnLog error:", err)
	}
	data.Data = string(b)
	var info EsLogInfo
	info.Es_index = es_index
	info.Es_type = es_type
	info.Es_id = es_id
	info.Info = data

	_eslogTuple.ptr_que.Push(info) //加入日志队列
}

/*
	更新本地存储文件地址
	isSave:是否本地存储
	LogFile:本地存储相对程序位置(log/  ==> 当前可执行文件的 log/目录)
*/
func InitLogFileInfo(isSave, isSaveEs bool, LogFile string) {
	_eslogTuple.isSaveFile = isSave
	_eslogTuple.isSaveToEs = isSaveEs
	_eslogTuple.local_Log_file = LogFile
	if isSave {
		BuildDir(_eslogTuple.local_Log_file)
	}
}

func BuildDir(logfile string) {
	os.MkdirAll(_eslogTuple.exe_path+"/"+logfile, os.ModePerm) //生成多级目录
}

/*
	消费者 消费日志
*/
func onConsumerLog() {
	for {
		var info EsLogInfo
		info = _eslogTuple.ptr_que.Pop().(EsLogInfo)

		if _eslogTuple.isSaveToEs && _eslogTuple.elastic.Client != nil {
			if !_eslogTuple.elastic.Add(info.Es_index, info.Es_type, info.Es_id, info.Info) {
				log.Println("elastic add error ")
			}
		}

		if _eslogTuple.isSaveFile {
			saveLogTofile(info)
		}
		Debug(info)
	}
}

var _f *os.File
var _err error
var saveFaile string

func saveLogTofile(info EsLogInfo) {

	time_str := time.Now().Format("2006-01-02-15") //设定时间格式
	fname := fmt.Sprintf("%s/%s/%s.log", _eslogTuple.exe_path, _eslogTuple.local_Log_file, time_str)
	if saveFaile != fname {
		if _f != nil {
			_f.Close()
		}
		_f, _err = os.OpenFile(fname, os.O_CREATE|os.O_APPEND|os.O_RDWR, 0666)
		if _err != nil {
			log.Println(_err)
			return
		}
	}

	b, _ := json.Marshal(info)
	_f.WriteString(string(b) + "\r\n") //输出堆栈信息
}
